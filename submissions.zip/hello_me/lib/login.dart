import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hello_me/UserRepository.dart';
import 'package:hello_me/UserRepository.dart';

class login extends StatefulWidget {
  final UserRepository user;
  login({this.user});
  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<login> {
  bool isLoading = false;
  TextEditingController _email;
  TextEditingController _password;

  @override
  void initState() {
    super.initState();
    _email = TextEditingController(text: "");
    _password = TextEditingController(text: "");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: Text('Login Screen'),
        ),
        body: Builder(
            builder: (context) => Center(
                    child: ListView(children: <Widget>[
                  Container(
                      alignment: Alignment.bottomCenter,
                      padding: EdgeInsets.all(100),
                      child: Text(
                        'LOG IN',
                        style: TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w500,
                            fontSize: 50),
                      )),
                  Container(
                    padding: EdgeInsets.all(10),
                    child: TextField(
                      controller: _email,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Email',
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                    child: TextField(
                      obscureText: true,
                      controller: _password,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Password',
                      ),
                    ),
                  ),
                  FlatButton(
                    onPressed: () {
                      //forgot password screen
                    },
                    textColor: Colors.red,
                    child: Text('Forgot Password'),
                  ),
                  Container(
                      alignment: Alignment.bottomCenter,
                      height: 35,
                      padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                      child: isLoading
                          ? CircularProgressIndicator()
                          : RaisedButton(
                              textColor: Colors.white,
                              color: Colors.red,
                              child: Text('Login'),
                              onPressed: () async {
                                setState(() {
                                  isLoading = true;
                                });
                                if (!await widget.user
                                    .signIn(_email.text, _password.text)) {
                                  setState(() {
                                    isLoading = false;
                                  });
                                  Scaffold.of(context).showSnackBar(SnackBar(
                                      content:
                                          Text('There was an error logging '
                                              'into the app')));
                                } else {
                                  setState(() {
                                    isLoading = false;
                                  });
                                  Navigator.pop(context);
                                }
                              },
                            )),
                ]))));
    ;
  }
}
